=========================================================
                  -- TME ?? AR --
=========================================================

-- ---------------------- Etudiants ---------------------
-- NOM          : PITTON
-- PRENOM       : Olivier
-- NO ETUDIANT  : 2800439

-- NOM          : 
-- PRENOM       : 
-- NO ETUDIANT  : 
-- ------------------------------------------------------

-- ----------------- Directives Makefile ----------------
-- make           : Construit tous les binaires des
	              	  execices 1 a ??

-- make exerciceX : Construit le binaire de 
                    l'exercice X.

-- make runX      : Execute le binaire de l'exerciceX
                    avec des argument par defaut

-- make clean     : Detruit tous les fichiers objets 
                    ainsi que tous les executables 
-- ------------------------------------------------------

-- --------------- Reponses aux questions ---------------
