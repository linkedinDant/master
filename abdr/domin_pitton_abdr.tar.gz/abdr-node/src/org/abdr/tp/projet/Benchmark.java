package org.abdr.tp.projet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletResponse;

import org.abdr.http.HttpClient;
import org.abdr.http.response.Response;
import org.abdr.node.Node;
import org.abdr.tp.M3;
import org.abdr.transaction.SerializableKey;
import org.abdr.transaction.WriteTransaction;
import org.abdr.transaction.impl.StandardWriteTransaction;

public class Benchmark implements Callable<List<Long>> {

	static public final int nbIter = 100;

	private Node node;
	private int val;

	public Benchmark(Node node, int val) {
		this.node = node;
		this.val = val;
	}

	@Override
	public List<Long> call() throws Exception {
		List<Long> time = new ArrayList<>();
		try (HttpClient client = new HttpClient()) {
			Response r = client.writeTransaction(createStandard(), node);
			for (int i = 0; i < nbIter; i++) {
				r = client.writeTransaction(createStandardMultiObj(), node);
				assert (r.getStatus() == HttpServletResponse.SC_OK) : "Le code d'erreur est " + r.getStatus();
				time.add(r.getTime());
			}
		}
		return time;
	}

	private final WriteTransaction createStandardMultiObj() throws IOException {
		String profile = "P" + val;
		Map<SerializableKey, byte[]> values = new HashMap<>(100);
		for (int i = 0; i < 100; i++) {
			Data d = new Data(i, i, i, i, i);
			SerializableKey key = new SerializableKey(profile, Integer.toString(i));
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(out);
			oos.writeObject(d);
			oos.flush();
			values.put(key, out.toByteArray());
			out.close();
			oos.close();
		}
		return new M3(new ArrayList<>(values.keySet()), values);
	}

	private final WriteTransaction createStandard() throws IOException {
		String profile = "P" + val;
		Map<SerializableKey, byte[]> values = new HashMap<>(100);
		for (int i = 0; i < 100; i++) {
			Data d = new Data(i, i, i, i, i);
			SerializableKey key = new SerializableKey(profile, Integer.toString(i));
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(out);
			oos.writeObject(d);
			oos.flush();
			values.put(key, out.toByteArray());
			out.close();
			oos.close();
		}
		return new StandardWriteTransaction(new ArrayList<>(values.keySet()), values);
	}

}
