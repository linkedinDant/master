#ifndef _VAR_H
#define _VAR_H

/**
 * Nombre d'entee dans le vecteur de callout 
 */
#define MAX_CALLOUT 100   

/**
 * struct v
 */
struct {
  int    v_hsize;
  int    v_hmask;
  struct callo ve_callout[MAX_CALLOUT];
}v;

#endif /* _VAR_H */
