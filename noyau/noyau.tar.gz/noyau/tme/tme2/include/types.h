#ifndef _TYPES_H
#define _TYPES_H

/**
 * disk address
 */
typedef long  bc_daddr_t;   
/**
 * device code
 */
typedef int   bc_dev_t;     
/**
 * core address
 */
typedef char *bc_caddr_t;   

#endif /* _TYPES_H */
