package org.tp.strategy;

import java.util.List;

import org.tp.storage.ChunkStorage;

public class RoundRobinStrategy implements ChunkStrategy {

  private int cpt = 0;
  

  @Override
  public boolean isRandom() {
    return true;
  }
  
  @Override
  public ChunkStorage select(String chunkName, List<ChunkStorage> servers) {
    int next = cpt % servers.size();
    ++cpt;
    return servers.get(next);
  }

}
