package org.tp.strategy;

import java.util.List;

import org.tp.storage.ChunkStorage;

public class HashStrategy implements ChunkStrategy {

  public HashStrategy() {
  }

  @Override
  public boolean isRandom() {
    return false;
  }

  @Override
  public ChunkStorage select(String chunkName, List<ChunkStorage> servers) {
    int hash = Math.abs(chunkName.hashCode()) % servers.size();
    return servers.get(hash);
  }

}
