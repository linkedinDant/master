package org.tp.storage;

import org.tp.strategy.ChunkStrategy;

/**
 * Une factory de création de ChunkStorage.
 * @author pitton
 *
 */
public class ChunkStorageFactory {

  public ChunkStorageFactory() {
  }
  
  public ChunkStorage create() {
    return new ChunkStorageImpl();
  }
  
  public ChunkStorage createComposite(ChunkStrategy st) {
    return new ChunkStorageComposite(st);
  }

  public ChunkStorage createFS() {
    return new ChunkStorageFS();
  }
  
}
