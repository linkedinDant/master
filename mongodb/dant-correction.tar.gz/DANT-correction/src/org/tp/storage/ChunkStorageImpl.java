package org.tp.storage;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.tp.chunk.Chunk;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.ServerAddress;

public class ChunkStorageImpl extends AbstractChunkStorage {

  static private final String DB_NAME = "chunk";

  private DBCollection coll;

  @Override
  public synchronized ChunkStorage start(String collection, ServerAddress... addr) throws IllegalStateException, UnknownHostException {
    if (isStarted()) {
      throw new IllegalStateException("Already started");
    }
    if (addr == null || addr.length == 0) {
      throw new IllegalArgumentException("Need at least one address");
    }
    Mongo m = new Mongo(addr[0]);
    this.coll = m.getDB(DB_NAME).getCollection(collection);
    System.err.println("Node " + toString() + " is starting");
    started = true;
    return this;
  }

  @Override
  public synchronized void close() throws IllegalStateException {
    if (isStarted() == false) {
      throw new IllegalStateException("Already closed");
    }
    System.err.println("Node " + toString() + " is closing");
    coll.getDB().getMongo().close();
    started = false;
  }

  @Override
  public void add(Chunk chunk) {
    DBObject dbObject = toDbObject(chunk);
    System.err.println("[" + toString() + "] is saving : " + chunk);
    coll.insert(dbObject);
  }


  @Override
  public void add(List<Chunk> chunks) {
    DBObject[] content = new DBObject[chunks.size()];
    for(int i = 0 ; i < chunks.size() ; i++) {
      content[i] = toDbObject(chunks.get(i));
    }
    System.err.println("[" + toString() + "] is saving : " + chunks);
    coll.insert(content);
  }

  @Override
  public void remove(Chunk chunk) {
    System.err.println("[" + toString() + "] is removing : " + chunk);
    coll.remove(toDbObject(chunk));
  }
  
  @Override
  public long chunks() {
    DBCursor find = coll.find();
    try {
     return find.count(); 
    } finally {
      find.close();
    }
  }
  
  @Override
  public Chunk find(String name, long id) {
    DBObject query = new BasicDBObject();
    query.put("name", name);
    query.put("id", id);
    DBCursor find = coll.find(query);
    try {
      if (find.hasNext()) {
        DBObject next = find.next();
        return toChunk(next);
      }
    } finally {
      find.close();
    }
    return null;
  }

  @Override
  public List<Chunk> find(String name) {
    DBObject query = new BasicDBObject();
    query.put("name", name);
    DBCursor find = coll.find(query);
    List<Chunk> res = new ArrayList<Chunk>(find.count());
    try {
      while (find.hasNext()) {
        DBObject next = find.next();
        res.add(toChunk(next));
      }
    } finally {
      find.close();
    }
    return res;
  }

  
  @Override
  public String toString() {
    ServerAddress address = coll.getDB().getMongo().getAddress();
    return address.getHost() + ":" + address.getPort();
  }
}
