package org.tp.storage;

import org.tp.chunk.Chunk;
import org.tp.chunk.ChunkBuilder;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public abstract class AbstractChunkStorage implements ChunkStorage {

  protected boolean started;
  
  protected AbstractChunkStorage() {
    started = false;
  }
  
  @Override
  public final boolean isStarted() {
    return started;
  }
  
  protected DBObject toDbObject(Chunk chunk) {
    DBObject db = new BasicDBObject();
    db.put("id", chunk.getId());
    db.put("max", chunk.getMaxId());
    db.put("name", chunk.getName());
    db.put("content", chunk.getContent());
    return db;
  }

  protected Chunk toChunk(DBObject object) {
    ChunkBuilder builder = new ChunkBuilder();
    builder.setContent((byte[]) object.get("content"));
    builder.setIds((Long) object.get("id"), (Long) object.get("max"));
    builder.setName((String) object.get("name"));
    return builder.build();
  }
  
}
