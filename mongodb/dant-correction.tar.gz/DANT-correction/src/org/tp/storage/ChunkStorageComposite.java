package org.tp.storage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.tp.chunk.Chunk;
import org.tp.strategy.ChunkStrategy;

import com.mongodb.ServerAddress;

public class ChunkStorageComposite extends AbstractChunkStorage {

  private List<ChunkStorage> storages;
  private ChunkStrategy strategy;

  public ChunkStorageComposite(ChunkStrategy st) {
    strategy = st;
  }

  @Override
  public synchronized ChunkStorage start(String collection, ServerAddress... servers) throws IllegalStateException {
    if (isStarted()) {
      throw new IllegalStateException("Already started");
    }
    if (servers == null) {
      throw new IllegalArgumentException("Need at least one address");
    }
    ChunkStorageFactory factory = new ChunkStorageFactory();
    storages = new ArrayList<ChunkStorage>();
    for (ServerAddress serv : servers) {
      ChunkStorage create = factory.create();
      try {
        create.start(collection, serv);
        storages.add(create);
      } catch (IOException exception) {
        System.err.println("The server " + serv.getHost() + " on port " + serv.getPort() + " isn't reachable... It will be skipped.");
      }
    }
    if (storages.isEmpty() == false)
      started = true;

    return this;
  }

  @Override
  public synchronized void close() throws IllegalStateException {
    if (isStarted() == false) {
      throw new IllegalStateException("Already closed");
    }
    for (ChunkStorage st : storages) {
      st.close();
    }
    storages.clear();
    started = false;
  }

  @Override
  public void add(List<Chunk> chunks) {
    for (Chunk chunk : chunks) {
      ChunkStorage select = strategy.select(chunk.getName(), storages);
      select.add(chunk);
    }
  }

  @Override
  public void remove(Chunk chunk) {
    if (strategy.isRandom() == false) {
      ChunkStorage select = strategy.select(chunk.getName(), storages);
      select.remove(chunk);
      return;
    }
    for (ChunkStorage st : storages) {
      st.remove(chunk);
    }
  }

  @Override
  public long chunks() {
    long size = 0;
    for (ChunkStorage st : storages) {
      size += st.chunks();
    }
    return size;
  }

  @Override
  public void add(Chunk chunk) {
    ChunkStorage select = strategy.select(chunk.getName(), storages);
    select.add(chunk);
  }

  @Override
  public Chunk find(String name, long id) {
    if (strategy.isRandom() == false) {
      ChunkStorage select = strategy.select(name, storages);
      return select.find(name, id);
    }
    for (ChunkStorage st : storages) {
      Chunk find = st.find(name, id);
      if (find != null) {
        return find;
      }
    }
    return null;
  }

  @Override
  public List<Chunk> find(String name) {
    if (strategy.isRandom() == false) {
      ChunkStorage select = strategy.select(name, storages);
      return select.find(name);
    }
    List<Chunk> chunks = new ArrayList<Chunk>();
    for (ChunkStorage st : storages) {
      List<Chunk> find = st.find(name);
      chunks.addAll(find);
    }
    return chunks;
  }
  
  @Override
  public final String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Composite : ");
    sb.append(storages);
    return sb.toString();
  }
}
