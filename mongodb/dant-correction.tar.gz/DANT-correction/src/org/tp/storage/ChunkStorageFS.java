package org.tp.storage;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.tp.chunk.Chunk;
import org.tp.chunk.ChunkBuilder;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

public class ChunkStorageFS extends AbstractChunkStorage {

  static private final String DB_NAME = "chunk";

  private GridFS gridfs;

  @Override
  public synchronized ChunkStorage start(String collection, ServerAddress... addr) throws IllegalStateException, UnknownHostException {
    if (isStarted()) {
      throw new IllegalStateException("Already started");
    }
    if (addr == null || addr.length == 0) {
      throw new IllegalArgumentException("Need at least one address");
    }
    Mongo m = new Mongo(addr[0]);
    this.gridfs = new GridFS(m.getDB(DB_NAME));
    System.err.println("FS Node " + toString() + " is starting");
    started = true;
    return this;
  }

  @Override
  public synchronized void close() throws IllegalStateException {
    if (isStarted() == false) {
      throw new IllegalStateException("Already closed");
    }
    System.err.println("FS Node " + toString() + " is closing");
    this.gridfs.getDB().getMongo().close();
    started = false;
  }

  @Override
  public void add(Chunk chunk) {
    GridFSInputFile file = this.gridfs.createFile(chunk.getContent());
    file.setFilename(chunk.getName());
    DBObject meta = toDbObject(chunk);
    meta.removeField("content");
    file.setMetaData(meta);
    file.save();
  }

  @Override
  public void add(List<Chunk> chunks) {
    for (Chunk chunk : chunks) {
      add(chunk);
    }
  }

  @Override
  public void remove(Chunk chunk) {
    DBObject query = new BasicDBObject();
    query.put("$where", "this.metadata.name === \"" + chunk.getName() + "\" && this.metadata.id == " + chunk.getId());
    this.gridfs.remove(chunk.getName());
  }

  @Override
  public Chunk find(String name, long id) {
    DBObject query = new BasicDBObject();
    query.put("$where", "this.metadata.name === \"" + name + "\" && this.metadata.id == " + id);
    List<GridFSDBFile> find = this.gridfs.find(query);
    if (find.isEmpty()) {
      return null;
    }
    return toChunk(find.get(0));
  }

  @Override
  public List<Chunk> find(String name) {
    List<GridFSDBFile> find = this.gridfs.find(name);
    List<Chunk> list = new ArrayList<Chunk>(find.size());
    for (GridFSDBFile file : find) {
      list.add(toChunk(file));
    }
    return list;
  }

  @Override
  public long chunks() {
    DBCursor list = this.gridfs.getFileList();
    int val = list.count();
    list.close();
    return val;
  }

  protected Chunk toChunk(GridFSDBFile file) {
    ChunkBuilder bu = new ChunkBuilder();
    DBObject meta = file.getMetaData();
    bu.setIds((Long) meta.get("id"), (Long) meta.get("max")).setName(file.getFilename());
    InputStream st = null;
    try {
      st = file.getInputStream();
      byte[] b = new byte[st.available()];
      st.read(b);
      bu.setContent(b);
    } catch (IOException exception) {
      throw new MongoException("Error during fetch " + file.getFilename(), exception);
    } finally {
      if (st != null)
        try {
          st.close();
        } catch (IOException exception) {}
    }
    return bu.build();
  }

  @Override
  public String toString() {
    ServerAddress address = gridfs.getDB().getMongo().getAddress();
    return address.getHost() + ":" + address.getPort();
  }

}
