package org.tp.storage;

import java.io.Closeable;
import java.net.UnknownHostException;
import java.util.List;

import org.tp.chunk.Chunk;

import com.mongodb.ServerAddress;

/**
 * L'interface de stockage des chunks dans une base NoSQL. Cette interface possédera plusieurs implémentations, comme indiqué dans le sujet de TP.
 * @author pitton
 *
 */
public interface ChunkStorage extends Closeable {

  /**
   * Démarre une connexion avec le serveur NoSQL. Le nom de la collection est donné ainsi que le / les serveurs où se connecter.
   * <b>Cette méthode doit être thread-safe.</b>
   * @param collection Le nom de la collection sur laquelle effectuer les opérations
   * @param servers Une liste de serveurs. 
   * @return L'instance appelante
   * @throws IllegalStateException Si on appelle cette méthode, alors que l'on est déjà connecté.
   * @throws UnknownHostException Si l'un des serveurs n'est pas accessible.
   */
  ChunkStorage start(String collection, ServerAddress... servers) throws IllegalStateException, UnknownHostException;
  
  /**
   * Ferme la connexion au serveur NoSQL. <b>Cette méthode doit être thread-safe.</b>
   * @throws IllegalStateException Si la connexion n'est pas démarrée ou déjà coupée.
   */
  @Override
  void close() throws IllegalStateException;
  
  /**
   * Renvoie vrai si la connexion a bel et bien été effectuée via l'appel à {@link #start(String, ServerAddress...)}, faux sinon
   * @return vrai si la connexion a bel et bien été effectuée.
   */
  boolean isStarted();
  
  /**
   * Sauvegarde le chunk spécifié dans la base NoSQL
   * @param chunk Le chunk à sauvegarder
   */
  void add(Chunk chunk);
  
  /**
   * Sauvegarde les chunks spécifiés dans la base NoSQL
   * @param chunks Les chunks à sauvegarder
   */
  void add(List<Chunk> chunks);
  
  /**
   * Supprime le chunk. Attention, cette méthode ne doit supprimer que ce chunk, et non le fichier entier.
   * @param chunk Le chunk à supprimer
   */
  void remove(Chunk chunk);

  /**
   * Retourne le chunk dont le nom et l'identifiant ont été spécifiés.
   * @param name Le nom du chunk
   * @param id L'identifiant du chunk
   * @return Le chunk retrouvé, ou null s'il n'existe pas
   */
  Chunk find(String name, long id);

  /**
   * Retourne la liste des chunks associés au nom de fichier donné.
   * @param name Un nom de fichier
   * @return La liste des chunks retrouvés
   */
  List<Chunk> find(String name);
  
  /**
   * Renvoie le nombre de chunks présents sur le serveur
   * @return le nombre de chunks présents sur le serveur
   */
  long chunks();
 
}
