package org.tp.chunk;

import static org.junit.Assert.*;

import org.junit.Test;

public class ChunkTest {

  final private ChunkFactory factory = new ChunkFactory();
  
  @Test
  public final void testGetName() {
    Chunk chunk = factory.create();
    String first = "Salut";
    chunk.setName(first);
    assertEquals(chunk.getName(), first);
    String sec = "Salut2";
    chunk.setName(sec);
    assertEquals(chunk.getName(), sec);
  }

  @Test
  public final void testGetId() {
    Chunk chunk = factory.create();
    long fir = 5L;
    long sec = 3L;
    chunk.setId(fir);
    assertEquals(fir, chunk.getId());
    chunk.setId(sec);
    assertEquals(sec, chunk.getId());
  }

  @Test
  public final void testGetMaxId() {
    Chunk chunk = factory.create();
    long fir = 5L;
    long sec = 3L;
    chunk.setMaxId(fir);
    assertEquals(fir, chunk.getMaxId());
    chunk.setMaxId(sec);
    assertEquals(sec, chunk.getMaxId());
  }

  @Test
  public final void testGetContent() {
    Chunk chunk = factory.create();
    String first = "Salut";
    String sec = "Salut2";
    chunk.setContent(first.getBytes());
    assertArrayEquals(chunk.getContent(), first.getBytes());
    chunk.setContent(sec.getBytes());
    assertArrayEquals(chunk.getContent(), sec.getBytes());
  }

  @Test
  public final void testCompareTo() {
    Chunk chunk = factory.create("a", 1L, 3L, null);
    Chunk chunk2 = factory.create("b", 1L, 3L, null);
    assertTrue(chunk.compareTo(chunk2) < 0);
    assertTrue(chunk.compareTo(chunk) == 0);
    assertTrue(chunk2.compareTo(chunk2) == 0);
    chunk2.setName("a");
    assertTrue(chunk.compareTo(chunk2) == 0);
    chunk.setId(3L);
    assertTrue(chunk.compareTo(chunk2) < 0);
  }

  @Test
  public final void testEqualsObject() {
    Chunk chunk = factory.create("a", 1L, 3L, null);
    Chunk chunk2 = factory.create("a", 1L, 3L, null);
    assertTrue(chunk.equals(chunk2));
    chunk.setName("b");
    assertFalse(chunk.equals(chunk2));
    chunk.setName(chunk2.getName());
    chunk.setId(3L);
    assertFalse(chunk.equals(chunk2));
  }

  @Test
  public final void testToString() {
    Chunk chunk = factory.create("a", 1L, 3L, null);
    assertEquals(chunk.toString(), "a@1");
  }

}
