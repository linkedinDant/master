package org.tp.storage;

public class ChunkStorageImplTest extends AChunkStorage {

  @Override
  protected ChunkStorage createStorage(ChunkStorageFactory factory) {
    return factory.create();
  }

}
