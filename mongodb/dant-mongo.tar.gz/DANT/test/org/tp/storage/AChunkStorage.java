package org.tp.storage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.net.UnknownHostException;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.tp.chunk.Chunk;
import org.tp.chunk.ChunkBuilder;

import com.mongodb.ServerAddress;

public abstract class AChunkStorage {

  static final private String COL_TEST = "COL_TEST";

  final private ChunkStorageFactory factory = new ChunkStorageFactory();

  @Test
  public final void testAdd() throws IllegalStateException, UnknownHostException {
    String name = "testAdd";
    Chunk createChunk = createChunk(name);
    ChunkStorage storage = createStorage(factory).start(COL_TEST, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
    storage.add(createChunk);
    Chunk find = storage.find(name, 0);
    storage.remove(createChunk);
    storage.close();
    assertNotNull(find);
    assertEquals(find, createChunk);
  }

  @Test
  public final void testChunks() throws IllegalStateException, UnknownHostException {
    String name = "testChunks";
    Chunk first = createChunk(name, 0, 2);
    Chunk second = createChunk(name, 1, 2);
    Chunk third = createChunk(name, 2, 2);
    ChunkStorage storage = createStorage(factory).start(COL_TEST, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
    storage.add(first);
    storage.add(second);
    storage.add(third);
    long size = storage.chunks();
    storage.remove(first);
    storage.remove(second);
    storage.remove(third);
    storage.close();
    assertEquals(size, 3L);
  }

  @Test
  public final void testFindString() throws IllegalStateException, UnknownHostException {
    String name = "testFindAll";
    Chunk first = createChunk(name, 0, 2);
    Chunk second = createChunk(name, 1, 2);
    Chunk third = createChunk(name, 2, 2);
    ChunkStorage storage = createStorage(factory).start(COL_TEST, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
    storage.add(first);
    storage.add(second);
    storage.add(third);
    List<Chunk> find = storage.find(name);
    storage.remove(first);
    storage.remove(second);
    storage.remove(third);
    storage.close();
    assertNotNull(find);
    Collections.sort(find);
    assertEquals(find.get(0), first);
    assertEquals(find.get(1), second);
    assertEquals(find.get(2), third);
  }

  @Test
  public final void testFindStringLong() throws IllegalStateException, UnknownHostException {
    String name = "testFindId";
    Chunk first = createChunk(name, 0, 2);
    Chunk second = createChunk(name, 1, 2);
    Chunk third = createChunk(name, 2, 2);
    ChunkStorage storage = createStorage(factory).start(COL_TEST, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
    storage.add(first);
    storage.add(second);
    storage.add(third);
    Chunk find = storage.find(name, 1);
    storage.remove(first);
    storage.remove(second);
    storage.remove(third);
    storage.close();
    assertNotNull(find);
    assertEquals(find, second);
  }

  @Test
  public final void testRemove() throws IllegalStateException, UnknownHostException {
    String name = "testRemove";
    Chunk createChunk = createChunk(name);
    ChunkStorage storage = createStorage(factory).start(COL_TEST, new ServerAddress("localhost", 27017), new ServerAddress("localhost", 27018));
    storage.add(createChunk);
    storage.remove(createChunk);
    Chunk find2 = storage.find(name, createChunk.getId());
    storage.close();
    assertEquals(find2, null);
  }

  protected Chunk createChunk(String name, int id, int maxId) {
    ChunkBuilder b = new ChunkBuilder();
    b.setName(name);
    b.setContent(name.getBytes());
    b.setIds(id, maxId);
    return b.build();
  }

  protected Chunk createChunk(String name) {
    return createChunk(name, 0, 3);
  }


  abstract protected ChunkStorage createStorage(ChunkStorageFactory factory);
  
}
