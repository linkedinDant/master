package org.tp.strategy;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.tp.storage.ChunkStorage;
import org.tp.storage.ChunkStorageFactory;

public class HashStrategyTest {

  private final ChunkStrategy strategy = new ChunkStrategyFactory().createHash();
  
  @Test
  public final void testIsRandom() {
    assertFalse(strategy.isRandom());
  }

  @Test
  public final void testSelect() {
    List<ChunkStorage> dummy = createDummy();
    String chunkName = "SALUT";
    ChunkStorage select = strategy.select(chunkName, dummy);
    assertEquals(select, dummy.get(chunkName.hashCode() % dummy.size()));
    assertEquals(strategy.select(chunkName, dummy), dummy.get(chunkName.hashCode() % dummy.size()));
  }
  
  private final List<ChunkStorage> createDummy() {
    List<ChunkStorage> st = new ArrayList<>();
    ChunkStorageFactory fact = new ChunkStorageFactory();
    st.add(fact.create());
    st.add(fact.create());
    st.add(fact.create());
    st.add(fact.create());
    return st;
  }

}
