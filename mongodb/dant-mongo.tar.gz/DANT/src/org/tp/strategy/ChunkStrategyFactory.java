package org.tp.strategy;

/**
 * Une factory de création de stratégies
 * @author pitton
 *
 */
public class ChunkStrategyFactory {
  
  public ChunkStrategy createRR() {
    return null;
  }
  
  public ChunkStrategy createHash() {
    return null;
  }

}
