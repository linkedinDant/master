package org.tp.chunk;

import java.io.Serializable;

/**
 * L'interface commune à tous les chunks de fichiers. Chaque partie d'une donnée externe (fichiers, ...)
 * est découpée en chunks décrit ici. Un chunk est identifié par son nom et son identifiant. L'identifiant correspond 
 * à la partie découpée du chunk. Le 2ème chunk d'un fichier a l'identifiant 1.
 * @author pitton
 *
 */
public interface Chunk extends Serializable, Comparable<Chunk> {

  /**
   * Retourne le nom du chunk
   * @return le nom du chunk
   */
  String getName();

  /**
   * Modifie le nom du chunk
   * @param name Le nom du chunk
   */
  void setName(String name);

  /**
   * Retourne l'identifiant du chunk par rapport au split. 
   * @return l'identifiant du chunk par rapport au split.
   */
  long getId();

  /**
   * Modifie l'identifiant du chunk par rapport au split
   * @param id Le nouvel identifiant
   */
  void setId(long id);

  /**
   * Le nombre maximum de chunks associé au fichier de ce chunk. Si un fichier a été découpé en 4 parties, 
   * cette méthode doit renvoyer 4.
   * @return Le nombre maximum de chunks associé au fichier de ce chunk
   */
  long getMaxId();

  /**
   * Modifie le nombre maximum de chunks associé au fichier de ce chunk
   * @param maxId le nombre maximum de chunks associé au fichier de ce chunk
   */
  void setMaxId(long maxId);

  /**
   * Retourne le contenu du chunk
   * @return le contenu du chunk
   */
  byte[] getContent();

  /**
   * Modifie le contenu du chunk
   * @param content Le nouveau contenu
   */
  void setContent(byte[] content);

  @Override
  String toString();
  
}
