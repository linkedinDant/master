package org.correction.persistence;

import java.io.Closeable;
import java.net.UnknownHostException;
import java.util.List;

import org.correction.log.Loggable;

/**
 * L'interface commune à toutes les classes offrant un support de stockage à des {@link Loggable}.
 * Cette interface définit l'ensemble des méthodes permettant de sauvegarder / retrouver des {@link Loggable}. 
 * @author Pitton Olivier
 *
 */
public interface LoggableDAO extends Closeable, Iterable<Loggable> {

  /**
   * Retourne vrai si le composant est déjà démarré.
   * @return {@code boolean} vrai si le composant est déjà démarré, faux sinon
   */
  boolean isStart();
  
  /**
   * Démarre le composant courant. Si le composant est déjà démarré, cette méthode renvoie une {@link IllegalStateException}.
   * Cette méthode est <b>thread-safe</b>.
   * On initialise deux connexions dont les adresses sont spécifiées en paramètre. 
   * La première adresse définit le serveur où sont stockés les erreurs.
   * La seconde adresse définit le serveur où sont stockés les messages autres que des erreurs.
   * @return {@code LoggableDAO} l'instance courante
   * @throws IllegalStateException Si le composant est déjà démarré
   * @throws UnknownHostException Si la connexion a l'instance sous-jacente échoue. Problème de réseau, ...
   */
  LoggableDAO start() throws IllegalStateException, UnknownHostException;
  
  /**
   * Enregistre le {@link Loggable} spécifié dans le serveur qui lui est propre, erreur ou commun.
   * @param log {@link Loggable} un log
   * @return {@code LoggableDAO} l'instance courante
   */
  LoggableDAO persist(Loggable log) ;

  /**
   * Enregistre les {@link Loggable} spécifié dans les serveurs qui leur sont propres.
   * @param log {@link List} un ensemble de {@link Loggable}
   * @see #persist(Loggable) 
   * @return {@code LoggableDAO} l'instance courante
   */
  LoggableDAO persist(List<Loggable> logs) ;
  
  /**
   * Retourne tous les {@link Loggable} qui sont des erreurs ou des messages communs.
   * @param isError {@code boolean} vrai pour obtenir les erreurs.
   * @return {@link List} la liste des {@link Loggable}
   */
  List<Loggable> find(boolean isError) ;
  
  /**
   * Retourne tous les {@link Loggable} qui sont des erreurs et des messages communs.
   * @return {@link List} la liste des {@link Loggable}
   */
  List<Loggable> find() ;
  
  /**
   * Retourne tous les {@link Loggable} qui ont été publiés après la durée spécifié, qu'ils soient en erreur ou non.
   * @param time {@code long} une date
   * @return {@link List} la liste des {@link Loggable}
   */
  List<Loggable> findAfter(long time) ;
  
  /**
   * Vide l'ensemble des {@link Loggable} des serveurs
   */
  void clear() ;
  
  /**
   * Libère les ressources.
   * @exception IllegalStateException Si le ocmposant n'est pas démarré
   */
  @Override
  void close() throws IllegalStateException ;
  
}
