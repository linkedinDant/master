package org.correction.persistence.impl;

import org.correction.persistence.LoggableDAO;

import com.mongodb.ServerAddress;

/**
 * Une factory de création de {@link LoggableDAO}
 * @author Pitton Olivier
 *
 */
public final class LoggableDAOFactory {

  public LoggableDAOFactory() {
  }
  

  /**
   * Crée un {@link LoggableDAO} bindé sur l'host et le port du serveur MongoDB auquel se connecter
   * @param host {@link String} un host
   * @param port {@code int} un port
   * @return {@link LoggableDAO} une instance nouvellement créée
   */
  public LoggableDAO createDefault(String host, int port) {
    return new DefaultLoggableDAOImpl(host, port);
  }


  /**
   * Crée un {@link LoggableDAO} composite contenant les adresses des serveurs d'erreur et communs MongoDB
   * @param error {@link ServerAddress} l'adresse du serveur d'erreur
   * @param common {@link ServerAddress} l'adresse du serveur commun
   * @return {@link LoggableDAO} une instance nouvellement créée
   */
  public LoggableDAO createComposite(ServerAddress first, ServerAddress second) {
    return new LoggableDAOComposite(first, second);
  }
  
}
