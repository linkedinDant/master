package org.correction.persistence.impl;

import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.List;

import org.correction.log.Loggable;
import org.correction.persistence.LoggableDAO;

import com.mongodb.ServerAddress;

public class LoggableDAOComposite implements LoggableDAO {

  private LoggableDAO error, common;
  private boolean isStart;
  private ServerAddress addrError, addrCommon;

  LoggableDAOComposite(ServerAddress error, ServerAddress common) {
    addrError = error;
    addrCommon = common;
  }

  @Override
  public boolean isStart() {
    return isStart;
  }

  @Override
  public synchronized LoggableDAO start() throws IllegalStateException, UnknownHostException {
    if (isStart())
      throw new IllegalStateException("Déjà démarré");

    LoggableDAOFactory factory = new LoggableDAOFactory();
    error = factory.createDefault(addrError.getHost(), addrError.getPort()).start();
    common = factory.createDefault(addrCommon.getHost(), addrCommon.getPort()).start();
    isStart = true;
    return this;
  }

  @Override
  public LoggableDAO persist(Loggable log) {
    if (log.isError()) {
      error.persist(log);
    } else {
      common.persist(log);
    }
    return this;
  }

  @Override
  public LoggableDAO persist(List<Loggable> logs) {
    for (Loggable log : logs) {
      if (log.isError()) {
        error.persist(log);
      } else {
        common.persist(log);
      }
    }
    return this;
  }

  @Override
  public List<Loggable> find(boolean isError) {
    return (isError) ? error.find(isError) : common.find(isError);
  }

  @Override
  public List<Loggable> find() {
    List<Loggable> find = error.find();
    find.addAll(common.find());
    return find;
  }

  @Override
  public List<Loggable> findAfter(long time) {
    List<Loggable> find = error.findAfter(time);
    find.addAll(common.findAfter(time));
    return find;
  }

  @Override
  public void clear() {
    error.clear();
    common.clear();
  }

  @Override
  public Iterator<Loggable> iterator() {
    return find().iterator();
  }

  @Override
  public synchronized void close() throws IllegalStateException {
    if (isStart() == false)
      throw new IllegalStateException("N'est pas démarré");
    error.close();
    common.close();
    isStart = false;
  }
}
