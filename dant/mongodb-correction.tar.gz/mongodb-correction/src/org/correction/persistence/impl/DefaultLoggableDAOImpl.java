package org.correction.persistence.impl;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.correction.converter.LoggableConverter;
import org.correction.converter.impl.LoggableConverterFactory;
import org.correction.log.Loggable;
import org.correction.persistence.LoggableDAO;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;

public class DefaultLoggableDAOImpl implements LoggableDAO {

  private boolean isStart = false;
  private Mongo common;
  private DBCollection commonCol;
  private LoggableConverter converter;
  private String host;
  private int port;

  DefaultLoggableDAOImpl(String host, int port) {
    this.host = host;
    this.port = port;
  }

  @Override
  public synchronized LoggableDAO start() throws IllegalStateException, UnknownHostException {
    if (isStart())
      throw new IllegalStateException("Déjà démarré");
    this.common = new Mongo(host, port);
    final String name = "log";
    this.commonCol = this.common.getDB(name).getCollection(name);
    this.converter = new LoggableConverterFactory().create();
    this.isStart = true;
    return this;
  }

  @Override
  public LoggableDAO persist(Loggable log) {
    DBObject convert = converter.convert(log);
    commonCol.insert(convert);
    return this;
  }

  @Override
  public LoggableDAO persist(List<Loggable> logs) {
    for (Loggable log : logs) {
      persist(log);
    }
    return this;
  }

  @Override
  public List<Loggable> find(boolean isError) {
    DBCursor find = commonCol.find();
    return find(find);
  }

  @Override
  public List<Loggable> find() {
    return find(commonCol.find());
  }

  @Override
  public List<Loggable> findAfter(long time) {
    BasicDBObject query = new BasicDBObject("time", new BasicDBObject("$gte", time));
    return find(commonCol.find(query));
  }

  @Override
  public void clear() {
    commonCol.remove(new BasicDBObject());
  }

  @Override
  public boolean isStart() {
    return isStart;
  }

  @Override
  public Iterator<Loggable> iterator() {
    return find().iterator();
  }

  @Override
  public synchronized void close() {
    if (isStart() == false)
      throw new IllegalStateException("N'est pas démarré");
    common.close();
    isStart = false;
  }

  protected final List<Loggable> find(DBCursor cursor) {
    try {
      List<Loggable> logs = new ArrayList<Loggable>(cursor.size());
      for (DBObject obj : cursor) {
        logs.add(converter.convert(obj));
      }
      return logs;
    } finally {
      cursor.close();
    }
  }
}
