package org.correction.log;

import java.io.Serializable;
import java.util.logging.Level;

/**
 * L'interface de tous les objets contenant des données de type log.
 * @author Pitton Olivier
 *
 */
public interface Loggable extends Serializable {

  /**
   * Retourne le message du log
   * @return {@link String} le message
   */
  String getMessage();
  
  /**
   * Modifie le message
   * @param message {@link String} le nouveau message
   */
  void setMessage(String message);
  
  /**
   * Retourne le niveau d'erreur
   * @return {@link Level} le niveau d'erreur
   */
  Level getLevel();
  
  /**
   * Modifie le niveau d'erreur. Si le niveau d'erreur n'existe pas, on renvoie une erreur.
   * @param leve {@link String} le nouveau niveau d'erreur
   * @throws IllegalArgumentException Si le niveau d'erreur n'existe pas, comme "FATAL".
   */
  void setLevel(String level) throws IllegalArgumentException;
  
  /**
   * Modifie le niveau d'erreur
   * @param level {@link Level} le nouveau niveau d'erreur
   */
  void setLevel(Level level);
  
  /**
   * Retourne vrai si le log courant est une erreur. 
   * Une erreur est un log dont le {@link Level} est {@link Level#WARNING} ou {@link Level#SEVERE}, et qui n'est pas null.
   * @return {@code boolean} vrai si le log courant est une erreur.
   */
  boolean isError();
  
  /**
   * Retourne la date de publication du log
   * @return {@code long} la date de publication du log
   */
  long getTime();
  
  /**
   * Modifie la date de publication du log
   * @param time {@code long} la nouvelle date de publication du log
   */
  void setTime(long time);
  
}
