package org.correction.log.impl;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;

import org.correction.log.Loggable;
import org.correction.visitor.Formattable;
import org.correction.visitor.LogVisitable;
import org.correction.visitor.LogVisitor;

public class Log implements Loggable, Formattable, LogVisitable {

  private static final long serialVersionUID = -5494571100798638540L;
  private String message;
  private long time;
  private Level level;

  Log() {
  }

  Log(Level level, String message, long time) {
    this.message = message;
    this.time = time;
    this.level = level;
  }

  @Override
  public String getMessage() {
    return this.message;
  }

  @Override
  public void setMessage(String message) {
    this.message = message;
  }

  @Override
  public long getTime() {
    return this.time;
  }

  @Override
  public void setTime(long time) {
    this.time = time;
  }

  @Override
  public boolean isError() {
    return level != null && (level.equals(Level.SEVERE) || level.equals(Level.WARNING));
  }

  @Override
  public Level getLevel() {
    return this.level;
  }

  @Override
  public void setLevel(String level) throws IllegalArgumentException {
    this.setLevel(Level.parse(level));
  }

  @Override
  public void setLevel(Level level) {
    this.level = level;
  }

  @Override
  public String format() {
    StringBuilder builder = new StringBuilder();
    DateFormat format = SimpleDateFormat.getDateTimeInstance(SimpleDateFormat.SHORT, SimpleDateFormat.SHORT);
    builder.append(format.format(new Date(time))).append(" - ").append(level.getName()).append(" : ").append(message);
    return builder.toString();
  }

  @Override
  public void accept(LogVisitor visitor) throws IOException {
    visitor.visit(this);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.level == null) ? 0 : this.level.hashCode());
    result = prime * result + ((this.message == null) ? 0 : this.message.hashCode());
    result = prime * result + (int) (this.time ^ (this.time >>> 32));
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Log other = (Log) obj;
    if (this.level == null) {
      if (other.level != null)
        return false;
    } else if (!this.level.equals(other.level))
      return false;
    if (this.message == null) {
      if (other.message != null)
        return false;
    } else if (!this.message.equals(other.message))
      return false;
    if (this.time != other.time)
      return false;
    return true;
  }

  @Override
  public String toString() {
    return getMessage();
  }
}
