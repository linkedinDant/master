package org.correction.log.impl;

import java.util.logging.Level;

import org.correction.log.Loggable;

/**
 * Une factory de création de {@link Loggable}
 * @author Pitton Olivier
 *
 */
public final class LoggableFactory {

  public LoggableFactory() {
  }
  
  /**
   * Crée et renvoie un {@link Loggable} vide
   * @return {@link Loggable} un log
   */
  public Loggable createLoggable() {
    return new Log();
  }
  

  /**
   * Crée et renvoie un {@link Loggable} vide
   * @param level {@link Level} le niveau d'erreur
   * @param message {@link String} un message
   * @param time {@code long} la date de publication du log
   * @return {@link Loggable} un log
   */
  public Loggable createLoggable(Level level, String message, long time) {
    return new Log(level, message, time);
  }

}
