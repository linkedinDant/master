package org.correction.visitor.impl;

import java.io.IOException;
import java.io.OutputStream;

import org.correction.visitor.Formattable;
import org.correction.visitor.LogVisitor;

/**
 * Un visiteur qui écrit dans un {@link OutputStream}
 * @author Pitton Olivier
 *
 */
public class OutputStreamVisitor implements LogVisitor {

  final private OutputStream stream;
  
  OutputStreamVisitor(OutputStream stream) {
    this.stream = stream;
  }

  @Override
  public void visit(Formattable log) throws IOException {
    stream.write(log.format().getBytes());
    stream.flush();
  }

}
