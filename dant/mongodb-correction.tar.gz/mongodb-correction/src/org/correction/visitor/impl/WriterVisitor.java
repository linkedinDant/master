package org.correction.visitor.impl;

import java.io.IOException;
import java.io.Writer;

import org.correction.visitor.Formattable;
import org.correction.visitor.LogVisitor;

/**
 * Un visiteur qui écrit dans un {@link Writer}
 * @author Pitton Olivier
 *
 */
public class WriterVisitor implements LogVisitor {

  final private Writer writer;

  WriterVisitor(Writer writer) {
    this.writer = writer;
  }

  @Override
  public void visit(Formattable log) throws IOException {
    writer.write(log.format());
    writer.flush();
  }

}
