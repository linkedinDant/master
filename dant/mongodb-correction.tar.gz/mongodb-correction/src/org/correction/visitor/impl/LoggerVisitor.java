package org.correction.visitor.impl;

import java.io.IOException;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import org.correction.visitor.Formattable;
import org.correction.visitor.LogVisitor;
/**
 * Un visiteur qui écrit dans un {@link Logger}
 * @author Pitton Olivier
 *
 */
public class LoggerVisitor implements LogVisitor {

  final private Logger logger;

  LoggerVisitor(Logger logger) {
    this.logger = logger;
  }

  @Override
  public void visit(Formattable log) throws IOException {
    LogRecord logRecord = new LogRecord(log.getLevel(), log.getMessage());
    logRecord.setMillis(log.getTime());
    logger.log(logRecord);
  }

}
