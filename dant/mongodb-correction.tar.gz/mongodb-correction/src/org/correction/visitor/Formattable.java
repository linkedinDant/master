package org.correction.visitor;

import org.correction.log.Loggable;

/**
 * L'interface commune à tous les objets pouvant être formatté selon un style prédéfini
 * @author Pitton Olivier
 *
 */
public interface Formattable extends Loggable {

  /**
   * Formatte l'instance courante et la renvoie. Cette méthode est très similaire à {@link Object#toString()} 
   * @return {@link String} l'instance courante formattée.
   */
  String format();
  
}
