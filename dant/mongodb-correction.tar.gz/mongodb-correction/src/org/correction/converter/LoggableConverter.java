package org.correction.converter;

import org.correction.log.Loggable;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

/**
 * L'interface commune à tous les objets capable de transformer des {@link Loggable} en {@link DBObject} et réciproquement.
 * Ces méthodes sont consistentes. Ainsi de multiples appels à une méthode avec une référence toujours identique renverra un objet identique.
 * @author Pitton Olivier
 *
 */
public interface LoggableConverter {
  
  /**
   * Le nom de la propriété message pour le {@link DBObject}. 
   * L'objet JSON généré sera de la fome {"message": "message entré par l'utilisateur"}
   * @see {@link DBObject#put(String, Object)}
   */
  static public String MESSAGE_PROPERTY = "message";

  /**
   * Le nom de la propriété time pour le {@link DBObject}. 
   * L'objet JSON généré sera de la fome {"message": 100L}
   * @see {@link DBObject#put(String, Object)}
   */
  static public String TIME_PROPERTY = "time";

  /**
   * Le nom de la propriété level pour le {@link DBObject}. 
   * L'objet JSON généré sera de la fome {"level": "WARNING"}
   * @see {@link DBObject#put(String, Object)}
   */
  static public String LEVEL_PROPERTY = "level";

  /**
   * Convertit un {@link Loggable} en {@link DBObject}
   * @param log {@link Loggable} un log
   * @see BasicDBObject
   * @return {@link DBObject} l'objet MongoDB équivalent
   */
  DBObject convert(Loggable log);

  /**
   * Convertit un {@link DBObject} en {@link Loggable}
   * @param obj {@link DBObject} un objet MongoDB
   * @return {@link Loggable} un log
   */
  Loggable convert(DBObject obj);
}
