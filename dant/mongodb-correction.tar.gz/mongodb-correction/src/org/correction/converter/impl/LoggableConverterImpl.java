package org.correction.converter.impl;

import org.correction.converter.LoggableConverter;
import org.correction.log.Loggable;
import org.correction.log.impl.LoggableFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class LoggableConverterImpl implements LoggableConverter {

  private final LoggableFactory factory;

  LoggableConverterImpl() {
    this(new LoggableFactory());
  }

  LoggableConverterImpl(LoggableFactory factory) {
    this.factory = factory;
  }

  @Override
  public DBObject convert(Loggable log) {
    DBObject obj = new BasicDBObject();
    obj.put(LEVEL_PROPERTY, log.getLevel().getName());
    obj.put(MESSAGE_PROPERTY, log.getMessage());
    obj.put(TIME_PROPERTY, log.getTime());
    return obj;
  }

  @Override
  public Loggable convert(DBObject obj) {
    Loggable log = factory.createLoggable();
    log.setLevel((String) obj.get(LEVEL_PROPERTY));
    log.setMessage((String) obj.get(MESSAGE_PROPERTY));
    log.setTime((Long) obj.get(TIME_PROPERTY));
    return log;
  }
}
