package org.correction.converter.impl;

import org.correction.converter.LoggableConverter;
import org.correction.log.Loggable;
import org.correction.log.impl.LoggableFactory;

/**
 * Une factory permettant de créer des {@link LoggableConverter}
 * @author Pitton Olivier
 *
 */
public final class LoggableConverterFactory {

  /**
   * Crée un {@link LoggableConverter} par défaut
   * @return {@link LoggableConverter} un convertisseur
   */
  public LoggableConverter create() {
    return new LoggableConverterImpl();
  }

  /**
   * Crée un {@link LoggableConverter} avec la {@link LoggableFactory} spécifiée
   * @param factory {@link LoggableFactory} une factory de {@link Loggable}
   * @return {@link LoggableConverter} une convertisseur
   */
  public LoggableConverter create(LoggableFactory factory) {
    return new LoggableConverterImpl(factory);
  }

}
