package org.correction.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import org.correction.persistence.LoggableDAO;
import org.junit.AfterClass;
import org.junit.Test;
import org.correction.log.Loggable;

import com.mongodb.ServerAddress;

public class LoggableDAOCompositeTest extends AMongoTest {

	static private LoggableDAO create() throws UnknownHostException {
		return factory.createComposite(new ServerAddress(getErrorHost(),
				getErrorPort()), new ServerAddress(getCommonHost(),
				getCommonPort()));
	}

	@AfterClass
	static public void afterClass() throws IllegalStateException,
			UnknownHostException {
		LoggableDAO dao = create().start();
		try {
			dao.clear();
		} finally {
			dao.close();
		}
	}

	@Test(expected = IllegalStateException.class)
	public final void testStart() throws UnknownHostException {
		LoggableDAO dao = create();
		try {
			dao.start(); // Ne doit pas renvoyer d'erreur. On a réussi à se
							// connecter
			dao.start(); // Doit renvoyer un IllegalStateException
		} finally {
			dao.close();
		}
	}

	@Test(expected = IllegalStateException.class)
	public final void testClose() throws UnknownHostException {
		LoggableDAO dao = create().start();// Ne doit pas renvoyer d'erreur. On
											// a réussi à se connecter
		try {
			dao.close();
			dao.close(); // Doit renvoyer une erreur. On l'a déjà fermé
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testPersistLoggable() throws IllegalStateException,
			UnknownHostException {
		Loggable log = loggableFactory.createLoggable(Level.SEVERE, "test",
				100L);
		LoggableDAO dao = create().start();
		try {
			dao.persist(log);
			List<Loggable> find = dao.find();
			dao.clear();
			assertNotNull(find);
			assertEquals(1, find.size());
			assertEquals(log, find.get(0));
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testPersistListOfLoggable() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.SEVERE,
					Integer.toString(i), i));
		}
		LoggableDAO dao = create().start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.find();
			dao.clear();
			assertNotNull(find);
			assertEquals(size, find.size());
			for (int i = 0; i < size; i++) {
				assertEquals(
						loggableFactory.createLoggable(Level.SEVERE,
								Integer.toString(i), i), find.get(i));
			}
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testFindBoolean() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.SEVERE,
					Integer.toString(i), i));
		}
		LoggableDAO dao = create().start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.find();
			List<Loggable> find2 = dao.find(true);
			dao.clear();
			assertNotNull(find);
			assertNotNull(find2);
			assertEquals(size, find.size());
			assertEquals(size, find2.size());
			assertEquals(find, find2);
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testFindAfter() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.SEVERE,
					Integer.toString(i), i));
		}
		LoggableDAO dao = create().start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.findAfter(1L);
			dao.clear();
			assertNotNull(find);
			assertEquals(size - 1, find.size());
			for (int i = 0; i < size - 1; i++) {
				assertEquals(
						loggableFactory.createLoggable(Level.SEVERE,
								Integer.toString(i + 1), i + 1), find.get(i));
			}
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testFindOnServers() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.SEVERE,
					Integer.toString(i), i));
		}
		LoggableDAO dao = create().start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.find(false);
			List<Loggable> find2 = dao.find(true);
			dao.clear();
			assertNotNull(find);
			assertNotNull(find2);
			assertEquals(0, find.size());
			assertEquals(size, find2.size());
			assertEquals(logs, find2);
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testFindCommon() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.INFO,
					Integer.toString(i), i));
		}
		LoggableDAO dao = create().start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.find(true);
			List<Loggable> find2 = dao.find(false);
			dao.clear();
			assertNotNull(find);
			assertNotNull(find2);
			assertEquals(0, find.size());
			assertEquals(size, find2.size());
			assertEquals(logs, find2);
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testFindEachOne() throws IllegalStateException,
			UnknownHostException {
		List<Loggable> logs = new ArrayList<Loggable>(2);
		logs.add(loggableFactory.createLoggable(Level.INFO, "test", 0L));
		logs.add(loggableFactory.createLoggable(Level.WARNING, "test", 0L));
		LoggableDAO dao = create().start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.find(false);
			List<Loggable> find2 = dao.find(true);
			dao.clear();
			assertNotNull(find);
			assertNotNull(find2);
			assertEquals(1, find.size());
			assertEquals(1, find2.size());
			assertEquals(logs.get(0), find.get(0));
			assertEquals(logs.get(1), find2.get(0));
		} finally {
			dao.close();
		}
	}
}
