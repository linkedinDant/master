package org.correction.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import org.correction.persistence.LoggableDAO;
import org.correction.persistence.impl.LoggableDAOFactory;
import org.junit.AfterClass;
import org.junit.Test;
import org.correction.log.Loggable;

public class DefaultLoggableDAOTest extends AMongoTest {

	@AfterClass
	static public void afterClass() throws IllegalStateException,
			UnknownHostException {
		LoggableDAO dao = new LoggableDAOFactory().createDefault(
				getErrorHost(), getErrorPort()).start();
		try {
			dao.clear();
		} finally {
			dao.close();
		}
	}

	@Test(expected = IllegalStateException.class)
	public final void testStart() throws UnknownHostException {
		LoggableDAO dao = new LoggableDAOFactory().createDefault(
				getErrorHost(), getErrorPort()).start();
		try {
			dao.start(); // Ne doit pas renvoyer d'erreur. On a réussi à se
							// connecter
			dao.start(); // Doit renvoyer un IllegalStateException
		} finally {
			dao.close();
		}
	}

	@Test(expected = IllegalStateException.class)
	public final void testClose() throws UnknownHostException {
		LoggableDAO dao = factory.createDefault(getErrorHost(), getErrorPort());
		try {
			dao.start(); // Ne doit pas renvoyer d'erreur. On a réussi à se
							// connecter
			dao.close();
			dao.close(); // Doit renvoyer une erreur. On l'a déjà fermé
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testPersistLoggable() throws IllegalStateException,
			UnknownHostException {
		Loggable log = loggableFactory.createLoggable(Level.SEVERE, "test",
				100L);
		LoggableDAO dao = factory.createDefault(getErrorHost(), getErrorPort()).start();
		try {
			dao.persist(log);
			List<Loggable> find = dao.find();
			dao.clear();
			assertNotNull(find);
			assertEquals(1, find.size());
			assertEquals(log, find.get(0));
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testPersistListOfLoggable() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.SEVERE,
					Integer.toString(i), i));
		}
		LoggableDAO dao = factory.createDefault(getErrorHost(), getErrorPort()).start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.find();
			dao.clear();
			assertNotNull(find);
			assertEquals(size, find.size());
			for (int i = 0; i < size; i++) {
				assertEquals(
						loggableFactory.createLoggable(Level.SEVERE,
								Integer.toString(i), i), find.get(i));
			}
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testFindBoolean() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.SEVERE,
					Integer.toString(i), i));
		}
		LoggableDAO dao = factory.createDefault(getErrorHost(), getErrorPort()).start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.find();
			List<Loggable> find2 = dao.find(true);
			dao.clear();
			assertNotNull(find);
			assertNotNull(find2);
			assertEquals(size, find.size());
			assertEquals(size, find2.size());
			assertEquals(find, find2);
		} finally {
			dao.close();
		}
	}

	@Test
	public final void testFindAfter() throws IllegalStateException,
			UnknownHostException {
		final int size = 3;
		List<Loggable> logs = new ArrayList<Loggable>(size);
		for (int i = 0; i < size; i++) {
			logs.add(loggableFactory.createLoggable(Level.SEVERE,
					Integer.toString(i), i));
		}
		LoggableDAO dao = factory.createDefault(getErrorHost(), getErrorPort()).start();
		try {
			dao.persist(logs);
			List<Loggable> find = dao.findAfter(1L);
			dao.clear();
			assertNotNull(find);
			assertEquals(size - 1, find.size());
			for (int i = 0; i < size - 1; i++) {
				assertEquals(
						loggableFactory.createLoggable(Level.SEVERE,
								Integer.toString(i + 1), i + 1), find.get(i));
			}
		} finally {
			dao.close();
		}
	}
}
