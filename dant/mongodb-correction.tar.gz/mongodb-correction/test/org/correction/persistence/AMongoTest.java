package org.correction.persistence;

import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.correction.persistence.impl.LoggableDAOFactory;
import org.junit.BeforeClass;
import org.correction.log.impl.LoggableFactory;

public abstract class AMongoTest {

	@BeforeClass
	static public void beforeClass() throws IOException {
		conf = new Properties();
		FileInputStream inStream = null;
		try {
			inStream = new FileInputStream("server_test.properties");
			conf.load(inStream);
		} finally {
			if (inStream != null)
				inStream.close();
		}
	}

	static private Properties conf;
	static protected final LoggableDAOFactory factory = new LoggableDAOFactory();
	static protected final LoggableFactory loggableFactory = new LoggableFactory();

	static public String getErrorHost() {
		return getProperty("error.host");
	}

	static public int getErrorPort() {
		return Integer.parseInt(getProperty("error.port"));
	}

	static public String getCommonHost() {
		return getProperty("common.host");
	}

	static public int getCommonPort() {
		return Integer.parseInt(getProperty("common.port"));
	}

	static private String getProperty(String property) {
		String valeur = conf.getProperty(property);
		assertNotNull(valeur);
		return valeur;
	}

}
