package org.correction.log;

import static org.junit.Assert.*;

import java.util.logging.Level;

import org.correction.log.impl.LoggableFactory;
import org.junit.Test;

public class LoggableTest {

  final private LoggableFactory factory = new LoggableFactory();

  @Test
  public final void testToString() {
    String message = "salut";
    Loggable log = factory.createLoggable(Level.SEVERE, message, 100L);
    assertEquals(message, log.toString());
  }
  
  @Test
  public final void testSetter() {
    // On vérifie les getters / setters
    Loggable log = factory.createLoggable();
    String message = "test";
    Level all = Level.ALL;
    long time = System.currentTimeMillis();
    log.setMessage(message);
    log.setLevel(all);
    log.setTime(time);
    assertEquals(message, log.getMessage());
    assertEquals(time, log.getTime());
    assertEquals(all, log.getLevel());
  }

  @Test(expected = IllegalArgumentException.class)
  public final void testSetLevelString() {
    Loggable log = factory.createLoggable();
    log.setLevel(Level.INFO.getName()); // Valide
    assertEquals(Level.INFO, log.getLevel());
    log.setLevel("fakeLevel"); // Doit lever une erreur
  }

  @Test
  public final void testIsError() {
    // On vérifie que isError renvoie bien faux quand c'est WARNING ou SEVERE uniquement
    Loggable log = factory.createLoggable();
    log.setLevel(Level.WARNING);
    assertTrue(log.isError());
    log.setLevel(Level.SEVERE);
    assertTrue(log.isError());
    log.setLevel((Level) null);
    assertFalse(log.isError());
    log.setLevel(Level.INFO);
    assertFalse(log.isError());
    log.setLevel(Level.ALL);
    assertFalse(log.isError());
    log.setLevel(Level.OFF);
    assertFalse(log.isError());
  }

  @Test
  public final void testEqualsObject() {
    // On vérifie que les equals / hashCode sont bons
    long time = System.currentTimeMillis();
    String message = "test_message";
    Level severe = Level.SEVERE;
    Loggable first = factory.createLoggable(severe, message, time);
    Loggable second = factory.createLoggable(severe, message, time);
    assertEquals(first, second);
    assertEquals(first.hashCode(), second.hashCode());
    first.setMessage("test");
    assertFalse(first.equals(second));
    assertFalse(first.hashCode() == second.hashCode());
    first.setMessage(message);
    first.setTime(1L);
    assertFalse(first.equals(second));
    assertFalse(first.hashCode() == second.hashCode());
    first.setTime(time);
    first.setLevel(Level.INFO);
    assertFalse(first.equals(second));
    assertFalse(first.hashCode() == second.hashCode());
  }
}
