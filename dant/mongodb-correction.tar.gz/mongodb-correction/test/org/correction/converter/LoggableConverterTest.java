package org.correction.converter;

import static org.junit.Assert.*;

import java.util.logging.Level;

import org.correction.converter.impl.LoggableConverterFactory;
import org.correction.log.Loggable;
import org.correction.log.impl.LoggableFactory;
import org.junit.Test;

import com.mongodb.DBObject;

public class LoggableConverterTest {

  final private LoggableConverter converter = new LoggableConverterFactory().create();
  
  @Test
  public final void testConvertLoggable() {
    Loggable log = new LoggableFactory().createLoggable(Level.SEVERE, "test", System.currentTimeMillis());
    // Ne peut pas renvoyer null
    assertNotNull(converter.convert(log));
    // Même objet généré
    assertEquals(converter.convert(log), converter.convert(log));
    DBObject obj = converter.convert(log);
    // Les propriétés doivent être identiques
    assertEquals(obj.get(LoggableConverter.LEVEL_PROPERTY), log.getLevel().getName());
    assertEquals(obj.get(LoggableConverter.TIME_PROPERTY), log.getTime());
    assertEquals(obj.get(LoggableConverter.MESSAGE_PROPERTY), log.getMessage());
    Loggable convert = converter.convert(obj);
    assertNotNull(convert);
    assertEquals(log, convert); // On s'assure que la conversion d'un objet converti donne le même résultat 
  }

}
