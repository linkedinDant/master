package org.correction;

import org.correction.converter.LoggableConverterTest;
import org.correction.log.LoggableTest;
import org.correction.persistence.DefaultLoggableDAOTest;
import org.correction.persistence.LoggableDAOCompositeTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
  LoggableTest.class,
  LoggableConverterTest.class,
  DefaultLoggableDAOTest.class,
  LoggableDAOCompositeTest.class,
  FactoryTest.class
})
public class LogTestSuite {

}
