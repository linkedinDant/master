package org.tp.persistence.impl;

import org.tp.persistence.LoggableDAO;

import com.mongodb.ServerAddress;

/**
 * Une factory de création de {@link LoggableDAO}
 * @author Pitton Olivier
 *
 */
public final class LoggableDAOFactory {

  public LoggableDAOFactory() {
  }
  
  /**
   * Crée un {@link LoggableDAO} bindé sur l'host et le port du serveur MongoDB auquel se connecter
   * @param host {@link String} un host
   * @param port {@code int} un port
   * @return {@link LoggableDAO} une instance nouvellement créée
   */
  public LoggableDAO createDefault(String host, int port) {
    //TODO : Implement me
    return null;
  }

  /**
   * Crée un {@link LoggableDAO} composite contenant les adresses des serveurs d'erreur et communs MongoDB
   * @param error {@link ServerAddress} l'adresse du serveur d'erreur
   * @param common {@link ServerAddress} l'adresse du serveur commun
   * @return {@link LoggableDAO} une instance nouvellement créée
   */
  public LoggableDAO createComposite(ServerAddress error, ServerAddress common) {
    //TODO : Implement me
    return null;
  }
  
}
