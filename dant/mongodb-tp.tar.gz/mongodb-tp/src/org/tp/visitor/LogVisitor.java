package org.tp.visitor;

import java.io.IOException;

/**
 * L'interface de tous les visiteurs de {@link Formattable}. Chaque implémentation contiendra un type de flux / writer / logger différents.
 * Cette interface nous permet d'implémenter le design pattern Visitor, et offre un point d'entrée aux développeurs
 * désireux d'utiliser nos {@link Formattable}
 * @author Pitton Olivier
 *
 */
public interface LogVisitor {

  /**
   * Visite le {@link Formattable} spécifie et effectue un traitement sur ce-dernier.
   * @param log {@link Formattable} un log à visiter
   * @throws IOException Si une écriture échoue
   */
  void visit(Formattable log) throws IOException;
  
}
