package org.tp.visitor;

import java.io.IOException;

/**
 * L'interface de tous les visités par un {@link LogVisitor}. 
 * @author Pitton Olivier
 *
 */
public interface LogVisitable {

  /**
   * Accepte le {@link LogVisitor} spécifie.
   * Cette méthode se résume à appeler {@link LogVisitor#visit(Formattable)} sur l'objet courant, si celui-ci implémente l'interface {@link Formattable}.
   * @param visitor {@link LogVisitor} un visiteur
   * @throws IOException Si une erreur est levée durant la visite
   */
  void accept(LogVisitor visitor) throws IOException;
  
}
