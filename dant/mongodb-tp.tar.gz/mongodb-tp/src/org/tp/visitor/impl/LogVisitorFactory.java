package org.tp.visitor.impl;

import java.io.OutputStream;
import java.io.Writer;
import java.util.logging.Logger;

import org.tp.visitor.LogVisitor;

/**
 * Une factory de création de {@link LogVisitor}
 * @author Pitton Olivier
 *
 */
public final class LogVisitorFactory {

  public LogVisitorFactory() {
  }
  
  /**
   * Crée un {@link LogVisitor} utilisant un {@link Logger}
   * @param logger {@link Logger} un logger
   * @return {@link LogVisitor} l'instance adéquate
   */
  public LogVisitor createFromLogger(Logger logger) {
    return null;
  }

  /**
   * Crée un {@link LogVisitor} utilisant un {@link OutputStream}
   * @param logger {@link OutputStream} un flux
   * @return {@link LogVisitor} l'instance adéquate
   */
  public LogVisitor createFromStream(OutputStream stream) {
    return null;
  }

  /**
   * Crée un {@link LogVisitor} utilisant un {@link Writer}
   * @param logger {@link Writer} un writer
   * @return {@link LogVisitor} l'instance adéquate
   */
  public LogVisitor createFromWriter(Writer writer) {
    return null;
  }

}
