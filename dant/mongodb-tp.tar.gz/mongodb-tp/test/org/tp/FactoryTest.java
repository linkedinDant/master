package org.tp;

import static org.junit.Assert.assertNotNull;

import java.net.UnknownHostException;
import java.util.logging.Level;

import org.junit.Test;
import org.tp.converter.impl.LoggableConverterFactory;
import org.tp.log.impl.LoggableFactory;
import org.tp.persistence.impl.LoggableDAOFactory;

import com.mongodb.ServerAddress;

public class FactoryTest {

  @Test
  public void loggableTest() {
    LoggableFactory factory = new LoggableFactory();
    assertNotNull(factory.createLoggable());
    assertNotNull(factory.createLoggable(Level.INFO, "test", System.currentTimeMillis()));
  }

  @Test
  public void loggableConverterTest() {
    LoggableConverterFactory factory = new LoggableConverterFactory();
    assertNotNull(factory.create());
    assertNotNull(factory.create(new LoggableFactory()));
  }

  @Test
  public void loggableDAOTest() throws UnknownHostException {
    LoggableDAOFactory factory = new LoggableDAOFactory();
    assertNotNull(factory.createComposite(new ServerAddress(), new ServerAddress()));
    assertNotNull(factory.createDefault("localhost", 27017));
  }

}
