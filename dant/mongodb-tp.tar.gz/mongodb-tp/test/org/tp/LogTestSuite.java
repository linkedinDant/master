package org.tp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.tp.converter.LoggableConverterTest;
import org.tp.log.LoggableTest;
import org.tp.persistence.DefaultLoggableDAOTest;
import org.tp.persistence.LoggableDAOCompositeTest;

@RunWith(Suite.class)
@SuiteClasses({
  LoggableTest.class,
  LoggableConverterTest.class,
  DefaultLoggableDAOTest.class,
  LoggableDAOCompositeTest.class,
  FactoryTest.class
})
public class LogTestSuite {

}
