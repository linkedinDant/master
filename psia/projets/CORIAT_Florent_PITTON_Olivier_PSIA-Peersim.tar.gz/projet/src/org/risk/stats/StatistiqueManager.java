package org.risk.stats;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.risk.model.Color;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Network;

public class StatistiqueManager {

	private static final List<StatEntry> takeRedPlanetes = new ArrayList<>();
	private static List<StatEntry> takeBluePlanetes = new ArrayList<>();

	static {
		takeRedPlanetes.add(new StatEntry(0L, (int) (Network.size() * Configuration.getDouble("red.percent"))));
		takeBluePlanetes.add(new StatEntry(0L, Network.size() - takeRedPlanetes.get(0).val));
	}

	private StatistiqueManager() {
	}

	static public void gnuplot() throws IOException {
		String filename = Configuration.getString("gnuplot.file");
		try (FileOutputStream fos = new FileOutputStream(filename + ".red")) {
			for (StatEntry val : takeRedPlanetes) {
				String content = val.getKey() + " " + val.getValue() + "\n";
				fos.write(content.getBytes());
				fos.flush();
			}
		}
		try (FileOutputStream fos = new FileOutputStream(filename + ".blue")) {
			for (StatEntry val : takeBluePlanetes) {
				String content = val.getKey() + " " + val.getValue() + "\n";
				fos.write(content.getBytes());
				fos.flush();
			}
		}
	}

	public static void incOrDecPlanete(Color color) {
		if (color == Color.RED) {
			incRedPlanete();
		} else {
			decRedPlanete();
		}
	}

	static void incRedPlanete() {
		int nbRed = takeRedPlanetes.get(takeRedPlanetes.size() - 1).val + 1;
		int nbBlue = takeBluePlanetes.get(takeBluePlanetes.size() - 1).val - 1;
		long time = CommonState.getTime();
		takeRedPlanetes.add(new StatEntry(time, nbRed));
		takeBluePlanetes.add(new StatEntry(time, nbBlue));
	}

	static void decRedPlanete() {
		int nbRed = takeRedPlanetes.get(takeRedPlanetes.size() - 1).val - 1;
		int nbBlue = takeBluePlanetes.get(takeBluePlanetes.size() - 1).val + 1;
		long time = CommonState.getTime();
		takeRedPlanetes.add(new StatEntry(time, nbRed));
		takeBluePlanetes.add(new StatEntry(time, nbBlue));
	}

	static private class StatEntry implements Map.Entry<Long, Integer> {

		private Long key;
		private Integer val;

		public StatEntry(Long key, Integer val) {
			this.key = key;
			this.val = val;
		}

		@Override
		public Long getKey() {
			return key;
		}

		@Override
		public Integer getValue() {
			return val;
		}

		@Override
		public Integer setValue(Integer value) {
			Integer oldVal = val;
			val = value;
			return oldVal;
		}

	}

}
