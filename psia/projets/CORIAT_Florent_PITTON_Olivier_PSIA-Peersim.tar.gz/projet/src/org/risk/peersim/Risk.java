package org.risk.peersim;

import java.util.logging.Logger;

import org.risk.model.Color;
import org.risk.model.Message;
import org.risk.model.NodeInformation;
import org.risk.model.RiskLogger;
import org.risk.model.RiskRandom;
import org.risk.stats.StatistiqueManager;

import peersim.config.Configuration;
import peersim.core.Network;
import peersim.core.Node;
import peersim.edsim.EDProtocol;

// Module principal
public class Risk implements EDProtocol {

	static private final Logger logger = RiskLogger.getLogger();
	
	private RiskTransport transport;
	final private String prefix;
	private Node node;
	private int pid;
	private NodeInformation info;

	public Risk(String prefix) {
		this.prefix = prefix;
	}

	public void setTransportLayer(Node node, int pid, Color color) {
		// On enregistre les informations du noeud. Appelée lors de l'initialisation
		this.node = node;
		this.transport = new RiskTransport(color);
		this.pid = pid;
		this.info = new NodeInformation(color);
	}

	void initVoisins() {
		// On construit le graphe
		int minVoisins = Configuration.getInt("min.voisins");
		int maxVoisins = Configuration.getInt("max.voisins");
		int nbVoisins = RiskRandom.random(minVoisins, maxVoisins);
		for (int i = 0; i < nbVoisins; i++) {
			// On récupèré un voisin et on tente de l'ajouter.
			int voisin = RiskRandom.random(0, Network.size());
			boolean res = setVoisin(voisin);
			// Si on n'a pas réussi à l'ajouter et que le nombre de voisins est toujours trop petit
			// on continue
			if (res == false && info.size() < minVoisins) {
				i--;
			}
		}
	}

	public NodeInformation getInformation() {
		return info;
	}
	
	public Node getNode() {
		return node;
	}

	@Override
	public void processEvent(Node node, int pid, Object event) {
		Message message = (Message) event;
		Color receive = message.getColor();
		// Si le message reçu est de la même couleur que nous, alors l'émetteur est venu nous aider
		if (receive == info.getColor()) {
			info.incSoldiers(message.getSoldiers());
			logger.info(String.format("[%s] a reçu %d soldats de %d.", this, message.getSoldiers(), message.getSrc()));
			return;
		}
		// C'est un message d'attaque
		// Si le nombre de soldats envoyés est plus grand que ce que l'on a, 
		// la planète est prise donc on change la couleur.
		if (message.getSoldiers() >= info.getSoldiers()) {
			this.info.setColor(message.getColor());
			StatistiqueManager.incOrDecPlanete(message.getColor());
			// Les soldats présents ont été convertis
			this.info.incSoldiers(message.getSoldiers());
			logger.info(String.format(
					"[%s] a été conquis par %d et a %d soldats.", this,
					message.getSrc(), info.getSoldiers()));
			return;
		}
		// On a réussi à défendre la planète. On supprime autant de soldats
		// que l'attaquant n'en a envoyé
		this.info.decSoldiers(message.getSoldiers());
		logger.info(String.format(
				"[%s] a été attaqué par %d et a gagné. Il possède %d soldats.",
				this, message.getSrc(), info.getSoldiers()));

	}

	public void send(Risk dest, int nbSoldier) {
		// Si le noeud n'a pas de soldats, il ne joue pas
		if (nbSoldier <= 0) {
			logger.info(String
							.format("[%s] ne peut pas jouer car il n'a plus de soldats.",
									this));
			return;
		}
		// On décrémente son nombre de soldats car il va les envoyer
		info.decSoldiers(nbSoldier);
		Message message = new Message(node.getID(), nbSoldier, info.getColor());
		// On envoie le message
		transport.send(dest.node, message, pid);
	}

	private boolean setVoisin(int index) {
		Risk voisin = (Risk) Network.get(index).getProtocol(pid);
		// Si c'est nous-même
		if (voisin.equals(this)) {
			return false;
		}
		// Si on a déjà ce voisin, on passe
		if (info.contains(voisin)) {
			return false;
		}
		// Si le voisin a assez de voisins, on ne l'ajoute pas
		if (voisin.info.size() >= Configuration.getInt("max.voisins")) {
			return false;
		}
		// On ajoute de manière bidirectionnelle. Ainsi, on s'assure que tous les noeuds
		// ont des arcs entrants et sortants
		info.addVoisins(voisin);
		voisin.info.addVoisins(this);
		return true;
	}

	@Override
	public Risk clone() {
		return new Risk(prefix);
	}

	@Override
	public boolean equals(Object ob) {
		if (ob instanceof Risk) {
			return node.getID() == ((Risk) ob).node.getID();
		}
		return false;
	}

	@Override
	public String toString() {
		return Long.toString(node.getID());
	}
}
