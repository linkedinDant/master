package org.risk.peersim;

import org.risk.model.Color;
import org.risk.model.Message;
import org.risk.model.RiskRandom;

import peersim.config.Configuration;
import peersim.core.Node;
import peersim.edsim.EDSimulator;

public class RiskTransport {

	private final int min, max;

	public RiskTransport(Color color) {
		min = Configuration.getInt("min." + color + ".latency");
		max = Configuration.getInt("max." + color + ".latency");
	}

	public void send(Node dest, Message msg, int pid) {
		EDSimulator.add(getLatency(), msg, dest, pid);
	}

	protected int getLatency() {
		return RiskRandom.random(min, max);
	}
}
