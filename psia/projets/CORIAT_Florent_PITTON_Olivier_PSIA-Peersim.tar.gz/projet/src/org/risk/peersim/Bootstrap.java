package org.risk.peersim;

import org.risk.model.Color;

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;

public class Bootstrap implements Control {

	public Bootstrap(String prefix) {
	}

	@Override
	public boolean execute() {
		final int pid = Configuration.getInt("default.protocol");
		final int size = Network.size();
		// Ce paramètre nous donne le pourcentage de planètes rouges
		// Donc réciproquement le nombre de planètes bleues
		final double p = Configuration.getDouble("red.percent");
		assert (p > 0.0 && p < 1.0);
		final int percent = (int) (p * size);
		for (int i = 0; i < size; i++) {
			Node node = Network.get(i);
			// On met les couleurs
			Risk risk = (Risk) node.getProtocol(pid);
			Color color = Color.BLUE;
			if (i < percent) {
				color = Color.RED;
			}
			// On donne au noeud le Node, le protole identifier
			// et sa couleur
			risk.setTransportLayer(node, pid, color);
		}
		// Une fois que tous les noeuds ont leurs couleurs etc...
		// On construit le graphe
		for (int i = 0; i < size; i++) {
			Risk risk = (Risk) Network.get(i).getProtocol(pid);
			risk.initVoisins();
		}
		return false;
	}

}
