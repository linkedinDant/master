package org.risk.peersim;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;

import org.risk.algo.RiskAlgo;
import org.risk.algo.RiskAlgoFactory;
import org.risk.model.Color;
import org.risk.model.RiskLogger;
import org.risk.stats.StatistiqueManager;

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;


public class RiskControl implements Control {

	static private final Logger logger = RiskLogger.getLogger();
	static private final RiskAlgoFactory factory = new RiskAlgoFactory();
	
	private List<Risk> nodes;

	public RiskControl(String prefix) {
		init();
	}

	void plot() {
		try {
			// On enregistre les stats
			StatistiqueManager.gnuplot();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public boolean execute() {
		// Méthode appelée tous les "step". Tous les noeuds jouent
		// Puisque les messages seront tous envoyés en même temps, on se fiche de
		// savoir si la liste est triée ou pas (car on ajoute le noeuds dans l'ordre d'id).
		for (int i = 0; i < nodes.size(); i++) {
			play(nodes.get(i));
		}
		// Pour savoir s'il y a un gagnant, on trie la liste par couleur
		// Si le premier et le dernier ont la même couleur, alors cette couleur
		// est la gagnante
		List<Risk> tmp = new ArrayList<>(nodes);
		Collections.sort(tmp, new ColorComparator());
		Color firstColor = tmp.get(0).getInformation().getColor();
		Color lastColor = tmp.get(tmp.size() - 1).getInformation().getColor();
		if (firstColor == lastColor) {
			// On a un gagnant
			logger.info("Le gagnant est le joueur de couleur " + firstColor);
			// On regarde s'il faut sauvegarder les statistiques de prise de planètes (la courbe d'évolution)
			if (Configuration.getBoolean("gnuplot.plot", false))
				// Si oui, on la sauvegarde
				plot();
			// On arrête l'exécution
			return true;
		}
		// Pas de gagnant on continue
		return false;
	}

	private void play(Risk src) {
		// Le noeud en param doit jouer. On crée un algo enfonction de la couleur
		// L'algo des bleus est standard (50% d'attaque / défense en random)
		// L'algo des rouges est décrit dans RedRiskAlgo
		RiskAlgo algo = factory.createAlgo(src.getInformation().getColor());
		// On récupère le noeud que l'on veut attaquer / défendre
		Risk dest = algo.choice(src);
		// On récupère le nombre de soldats à envoyer
		int nbSoldiers = algo.nbSoldiers(src, dest);
		// On envoie le message
		src.send(dest, nbSoldiers);
	}

	private final void init() {
		// On récupère tous les noeuds 
		// LE but sera d'itérer dessus pour les faire jouer à chaque tour
		int pid = Configuration.getInt("default.protocol");
		int size = Network.size();
		nodes = new ArrayList<>(size);
		for (int i = 0; i < size; i++) {
			Risk risk = (Risk) Network.get(i).getProtocol(pid);
			nodes.add(risk);
		}
	}

	static public class ColorComparator implements Comparator<Risk> {

		@Override
		public int compare(Risk o1, Risk o2) {
			return o1.getInformation().getColor()
					.compareTo(o2.getInformation().getColor());
		}

	}
}
