package org.risk.algo;

import org.risk.peersim.Risk;

public interface RiskAlgo {

	int nbSoldiers(Risk src, Risk dest);
	
	Risk choice(Risk src);
	
}
