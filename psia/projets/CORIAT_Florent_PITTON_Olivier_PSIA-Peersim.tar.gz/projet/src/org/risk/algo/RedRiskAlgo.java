package org.risk.algo;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.risk.model.NodeInformation;
import org.risk.peersim.Risk;

// L'algorithme des rouges
public class RedRiskAlgo implements RiskAlgo {

	@Override
	public int nbSoldiers(Risk src, Risk dest) {
		if(src.getInformation().getColor() == dest.getInformation().getColor()) {
			return defense(src, dest);
		}
		return attack(src, dest);
	}

	private int defense(Risk src, Risk dest) {
		// Tous nos voisins sont nos alliés (liaisons bidirectionnelles). Donc on ne peut pas être attaqué. On envoie tous nos soldats au plus faible.
		return src.getInformation().getSoldiers();
	}

	private int attack(Risk src, Risk dest) {
		// La meilleure défense est l'attaque. L'algorithme est le même
		int srcSoldiers = src.getInformation().getSoldiers();
		int destSoldiers = dest.getInformation().getSoldiers();
		// Si plus de soldats ou autant, on envoie juste le bon nombre pour être sur de prendre la planète
		if(srcSoldiers >= destSoldiers) {
			return destSoldiers;
		}
		// Sinon, c'est qu'il est plus fort, et on va l'affaiblir en sacrifiant nos soldats
		return srcSoldiers;
	}
	
	@Override
	public Risk choice(Risk src) {
		return selectWeak(src, src.getInformation().getVoisins());
	}
	
	protected Risk selectWeak(Risk src, List<Risk> voisins) {
		// La stratégie est la suivante :
		//  - On cherche le voisin ennemi qui a le plus de soldats, mais moins que le noeud attaquant. Ainsi 
		//    on convertira plein de soldats.
		//  - Si tous les ennemis sont plus forts, ou que l'on a que des alliés, on cherche à défendre / affaiblir
		int nbSoldiers = src.getInformation().getSoldiers();
		Collections.sort(voisins, new SoldierComparator());
		Risk weak = null;
		for(Risk voisin : voisins) {
			NodeInformation information = voisin.getInformation();
			if(information.getColor() == src.getInformation().getColor()) {
				continue;
			}
			// On attaque le plus faible pour être sur de prendre la planète.
			if(information.getSoldiers() <= nbSoldiers) {
				weak = voisin;
				continue;
			}
			// On a trouvé le plus faible, on attaque
			if(weak != null) {
				return weak;
			}
			// Si pas de plus faible, cela veut dire que tous les voisins ennemis sont plus forts
			// On passe directement en suicide / défense
			break;
		}
		// Défense / Affaiblissement
		return selectStrong(src, voisins);
	}

	private Risk selectStrong(Risk src, List<Risk> voisins) {
		Collections.sort(voisins, new SoldierComparator());
		int i = 0;
		while(i < voisins.size()) {
			Risk vois = voisins.get(i);
			i++;
			// On cherche le plus faible. Si le voisin a la même couleur, on passe. Il sera facilement convertit plus tard
			if(vois.getInformation().getColor() == src.getInformation().getColor()) {
				continue;
			}
			// On retourne le voisin le plus fort
			return vois;
		}
		// On retourne l'allié le plus faible
		return voisins.get(0);
	}
	
	static private class SoldierComparator implements Comparator<Risk> {

		@Override
		public int compare(Risk o1, Risk o2) {
			return o1.getInformation().getSoldiers() - o2.getInformation().getSoldiers();
		}
		
	}

}
