package org.risk.algo;

import org.risk.model.Color;

public final class RiskAlgoFactory {

	public RiskAlgo createAlgo(Color color) {
		if(color == Color.RED) {
			return new RedRiskAlgo();
		}
		return new BlueRiskAlgo();
	}

}
