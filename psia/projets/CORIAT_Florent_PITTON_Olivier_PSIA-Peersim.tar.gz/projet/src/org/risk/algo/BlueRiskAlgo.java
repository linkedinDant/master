package org.risk.algo;

import java.util.List;

import org.risk.model.RiskRandom;
import org.risk.peersim.Risk;

import peersim.config.Configuration;

public class BlueRiskAlgo implements RiskAlgo {

	@Override
	public Risk choice(Risk src) {
		List<Risk> voisins = src.getInformation().getVoisins();
		assert (voisins.size() > 0);
		int random = RiskRandom.random(0, voisins.size());
		return voisins.get(random);
	}

	@Override
	public int nbSoldiers(Risk src, Risk dest) {
		return (int) (src.getInformation().getSoldiers() * Configuration.getDouble("percent.blue.soldiers", 0.5));
	}

}
