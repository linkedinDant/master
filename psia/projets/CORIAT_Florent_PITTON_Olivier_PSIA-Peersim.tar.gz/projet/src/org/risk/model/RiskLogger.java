package org.risk.model;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.StreamHandler;

public final class RiskLogger {

	static private Logger logger;

	static synchronized public Logger getLogger() {
		if (logger == null) {
			logger = Logger.getLogger("risk");
			logger.setLevel(Level.INFO);
			logger.addHandler(new RiskHandler());
			logger.setUseParentHandlers(false);
		}
		return logger;
	}

	private RiskLogger() {
	}

	static private final class RiskFormatter extends Formatter {

		private final SimpleDateFormat formatter = new SimpleDateFormat(
				"HH:mm:ss");

		@Override
		public String format(LogRecord record) {
			String format = formatter.format(new Date(record.getMillis()));
			return String.format("[%s] %s: %s\n", format, record.getLevel()
					.getLocalizedName(), record.getMessage());
		}

	}

	static private final class RiskHandler extends StreamHandler {

		public RiskHandler() {
			super(System.err, new RiskFormatter());
		}

	}

}
