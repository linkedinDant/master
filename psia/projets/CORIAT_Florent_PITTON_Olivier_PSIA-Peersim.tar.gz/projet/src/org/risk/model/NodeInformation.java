package org.risk.model;

import java.util.ArrayList;
import java.util.List;

import org.risk.peersim.Risk;

import peersim.config.Configuration;

public class NodeInformation {

	private int soldiers;
	private Color color;
	private List<Risk> voisins;

	public NodeInformation(Color color) {
		this.color = color;
		this.voisins = new ArrayList<>();
		this.soldiers = Configuration.getInt("soldiers");
	}

	public int getSoldiers() {
		return soldiers;
	}

	public void incSoldiers(int soldiers) {
		this.soldiers += soldiers;
	}

	public void decSoldiers(int soldiers) {
		this.soldiers -= soldiers;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public List<Risk> getVoisins() {
		return voisins;
	}

	public int size() {
		return voisins.size();
	}

	public boolean contains(Risk voisin) {
		return voisins.contains(voisin);
	}

	public void addVoisins(Risk voisin) {
		this.voisins.add(voisin);
	}

}
