package org.risk.model;

import java.io.PrintStream;

public enum Color {

	RED(System.err),BLUE(System.out);
	
	private final PrintStream stream;
	
	private Color(PrintStream st) {
		stream = st;
	}
	
	public PrintStream getStream() {
		return stream;
	}
	
	@Override
	public String toString() {
		return name().toLowerCase();
	}
	
}
