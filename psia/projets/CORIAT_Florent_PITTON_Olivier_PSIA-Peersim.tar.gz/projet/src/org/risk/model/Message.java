package org.risk.model;

import java.io.Serializable;

public class Message implements Serializable {

	private int soldiers;
	private Color color;
	private long src;

	public Message() {
	}

	public Message(long src, int soldiers, Color color) {
		this.soldiers = soldiers;
		this.color = color;
		this.src = src;
	}

	public long getSrc() {
		return src;
	}

	public void setSrc(long src) {
		this.src = src;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public int getSoldiers() {
		return soldiers;
	}

	public void setSoldiers(int soldiers) {
		this.soldiers = soldiers;
	}

}
