package org.risk.model;

public final class RiskRandom {

	static public final int random(int min, int max) {
		return (int) (min + (Math.random() * (max - min)));
	}
	
	private RiskRandom() {
	}

}
