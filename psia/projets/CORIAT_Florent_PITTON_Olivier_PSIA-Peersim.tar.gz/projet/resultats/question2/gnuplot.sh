#!/bin/bash

rm -f *.png
gnuplot "gnuplot"
