package test;

public class SubTest {

	static {
		System.out.println("SubTest chargé !");
	}
	
}
