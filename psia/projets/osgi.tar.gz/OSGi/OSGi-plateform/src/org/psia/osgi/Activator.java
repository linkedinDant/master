package org.psia.osgi;

public interface Activator {

	void start(BundleContext context);
	
	void stop(BundleContext context);
	
}
