#include "exo4.h"
#define XOPEN_SOURCE 700

int main(int argc, char** argv) {  
  return EXIT_SUCCESS;
}