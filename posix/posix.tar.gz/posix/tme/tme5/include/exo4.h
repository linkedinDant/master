#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>
#include <sys/mman.h>    
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>

#define PHILOSOPHES 5