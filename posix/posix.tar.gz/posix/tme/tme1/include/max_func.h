
#ifndef MAX_FUNC
#define MAX_FUNC

int max_func(int vector[], int size);

#endif

